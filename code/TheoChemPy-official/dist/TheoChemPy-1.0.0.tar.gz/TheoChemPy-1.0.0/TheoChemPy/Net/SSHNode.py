import ssh

class SSHNode:
    def __init__(self, host, username = None, private_key = None, password = None, port = 22,):
        self._host = host
        self._username = username
        self._private_key = private_key
        self._password = password
        self._port = port

    def getFile(self, source, dest):
        ssh = Connection(self._host, self._username, self._private_key, self._password, self._port)
        ssh.get(source, dest)
        ssh.close()
        
    def putFile(self, source, dest):
        ssh = Connection(self._host, self._username, self._private_key, self._password, self._port)
        ssh.put(source, dest)
        ssh.close()

    def execute(self, command):
        ssh = Connection(self._host, self._username, self._private_key, self._password, self._port)
        out = ssh.execute(command)
        ssh.close()
        return out
        
